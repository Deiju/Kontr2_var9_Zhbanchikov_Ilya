import kotlinx.coroutines.*
suspend fun main(){
    var st1=Student1("","","","","","","",0,0.0)
    var n=0
    println("n=")
    n= readln()!!.toInt()
    println("Имя:")
    st1.name= readln()
    println("Фамилия:")
    st1.surname= readln()
    println("Отчество:")
    st1.otchestvo= readln()
    println("Пол:")
    st1.pol= readln()
    println("Дата рождения:")
    st1.date= readln()
    println("Группа:")
    st1.grup= readln()
    println("Вид спорта:")
    st1.sport= readln()
    println("Рост:")
    st1.height= readln()!!.toInt()
    println("Вес:")
    st1.weight= readln()!!.toDouble()
    println(st1.info())
    println("Соотношение веса и роста:")
    println(st1.soot())
    GlobalScope.launch {
        for (i in 1..n){
            delay(2000L)
            println("")
            println("Введите рост студента:")
            st1.height= readln()!!.toInt()
            println("Введите вес студента:")
            st1.weight= readln()!!.toDouble()
            println("Соотношение веса и роста:")
            println(st1.soot())
        }
    }
    delay(12000L*n)
}