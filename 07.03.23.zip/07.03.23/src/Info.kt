interface Info {
    var name:String
    var surname:String
    var otchestvo:String
    var pol:String
    var grup:String
    var date:String
    var height:Int
    var weight:Double
    var sport:String
    fun info():String
}