class Student1(_name:String,_surname:String,_otchestvo:String,_pol:String,_grup:String,_date:String,_sport:String,_height:Int,_weight:Double):Student(_name,_surname,_otchestvo,_pol,_grup,_date,_sport,_height,_weight) {
    override var name:String=_name
    override var surname:String=_surname
    override var otchestvo:String=_otchestvo
    override var pol:String=_pol
    override var grup:String=_grup
    override var date:String=_date
    override var sport:String=_sport
    override var height:Int=_height
    override var weight:Double=_weight
    override fun info():String{
        return "Имя:$name\nФамилия:$surname\nОтчество:$otchestvo\nПол:$pol\nГруппа:$grup\nДата рождения:$date\nРост:$height\nВес:$weight\nВид спорта:$sport"
    }
    fun soot():Double{
        return weight/(height*height)
    }
}