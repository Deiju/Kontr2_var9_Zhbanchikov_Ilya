abstract class Student(var _name:String,var _surname:String,var _otchestvo:String,var _pol:String,var _grup:String,var _date:String,var _sport:String,var _height:Int,var _weight:Double) {
    abstract var name:String
    abstract var surname:String
    abstract var otchestvo:String
    abstract var pol:String
    abstract var grup:String
    abstract var date:String
    abstract var sport:String
    abstract var height:Int
    abstract var weight:Double
    abstract fun info(): String
}